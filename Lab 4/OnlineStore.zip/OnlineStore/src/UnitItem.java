import java.util.Date;

public class UnitItem extends Item {
    //ATTRIBUTES
    private double unitPrice;
    private int quantity;
    private int quantityRemain;

    //CONSTRUCTOR
    public UnitItem(String name, String type, double[] size, double cost, double unitPrice, int quantity) {
        super(name, type, size, cost);
        this.unitPrice = unitPrice;
        this.quantity = quantity;
        this.quantityRemain = quantity;
    }

    //GETTERS
    @Override
    public double getPrice(){
        return unitPrice * quantityRemain;
    }
    @Override
    public double getPriceOnlyTax(){
        return (getPrice() * percentageIVA);
    }
    @Override
    public double getPricePlusTax(){
        return (getPrice() + getPriceOnlyTax());
    };
    public double getUnitPrice(){
        return unitPrice;
    }
    public int getQuantity(){
        return quantity;
    }

    //METHODS
    @Override
    public double calculateProfit(){
        if(quantity-quantityRemain == 0){
            return ((unitPrice-getCost()) * quantity) - getPriceOnlyTax();
        }else{
            return (unitPrice-getCost()) * (quantity-quantityRemain) - getPriceOnlyTax();
        }
    }
    @Override
    public double sumTotalTax(Taxable t) {
        return getPriceOnlyTax() + t.getPriceOnlyTax();
    }
    @Override
    public int compareTo(Item o) {
        return Double.compare(getPrice(), o.getPrice());
    }
    public double sell(int q){
        if (quantityRemain>=q){
            this.quantityRemain = this.quantityRemain - q;
            return q*unitPrice;
        }
        return 0;
    }

}
