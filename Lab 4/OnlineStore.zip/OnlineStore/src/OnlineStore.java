import java.time.LocalDate;
import java.util.Collections;
import java.util.LinkedList;

public class OnlineStore {
    //ATTRIBUTES
    private LinkedList<User> users;
    private LinkedList<Item> itemSold;
    private LinkedList<Item> itemAvailable;
    private LinkedList<AuctionItem> auctionItems;
    private LinkedList<Package> packages;
    private LinkedList<Sale> sales;
    private double totalPrice = 0;
    private double totalProfit = 0;
    private double totalTaxes = 0;
    private LocalDate currentDate;

    //CONSTRUCTOR
    public OnlineStore(LocalDate currentDate){
        itemAvailable = new LinkedList< Item >();
        itemSold = new LinkedList< Item >();
        auctionItems = new LinkedList< AuctionItem>();
        users = new LinkedList< User >();
        packages = new LinkedList< Package >();
        sales = new LinkedList< Sale >();
        this.currentDate = currentDate;
    }

    //METHODS
    public void calculatePrice(){
        totalPrice = 0;
        for (int i = 0; i < itemAvailable.size();i++){
            totalPrice += itemAvailable.get(i).getPricePlusTax();
        }
        System.out.println("Total Price: " + totalPrice);
    }
    public void calculateProfit(){
        totalProfit = 0;
        for (int i = 0; i < itemSold.size();i++){
            totalProfit += itemSold.get(i).calculateProfit();
        }
        System.out.println("Total Profit: " + totalProfit);
    }
    public void calculateTaxes(){
        totalTaxes = 0;
        for (int i = 0; i < itemSold.size(); i++){
            double temp = itemSold.get(i).sumTotalTax(itemSold.get(i).getPack());
            totalTaxes += temp;
        }
        System.out.println("Total Taxes: " + totalTaxes);
    }
    public void calculations(){
        calculatePrice();
        calculateProfit();
        calculateTaxes();
        }
    public void sortlists(Administrator admin){

        Collections.sort(itemAvailable);
        System.out.println("Currently available items: ");
        for (int i = 0; i < itemAvailable.size(); i++) {
            System.out.println(itemAvailable.get(i).getName());
        }
        System.out.println("");

        Collections.sort(itemSold);
        System.out.println("Currently sold items: ");
        for (int i = 0; i < itemSold.size(); i++) {
            System.out.println(itemSold.get(i).getName());
        }
        System.out.println("");

        Collections.sort(sales);
        System.out.println("Current sales: ");
        for (int i = 0; i < sales.size(); i++) {
            sales.get(i).printInfo();
        }
        System.out.println("");

        Collections.sort(auctionItems);
        admin.printStock(auctionItems);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

    }
    public void manageAuctions(Administrator user, LocalDate deliverydate){
        for (int i = 0; i < auctionItems.size(); i++){
            if(user.manageAuction(auctionItems.get(i),currentDate)){
                itemAvailable.remove(auctionItems.get(i));
                for (int j = 0; j < users.size(); j++){
                    if((users.get(j) instanceof Seller)){
                        sell(auctionItems.get(i).getBidder(), (Seller) users.get(j),auctionItems.get(i),deliverydate);
                    }
                }
                auctionItems.remove(i);
            }
        }
    }
    public void sell(Buyer buyer,Seller seller, Item i, LocalDate deliverydate){
        if((seller != null) && (seller.getAvailableItems().contains(i))){
            if((i instanceof UnitItem) || (i instanceof WeightedItem)){
                if(buyer != null){
                    itemAvailable.remove(i);
                    itemSold.add(i);

                    seller.sell(i);
                    buyer.buy(i);

                    System.out.println("Buyer " + buyer.getName() + " bought item " + i.getName() + " from seller " + seller.getName());

                    Sale s = new Sale(i,buyer,currentDate);
                    s.setDeliveryDate(deliverydate);
                    sales.add(s);
                }
            }else{
                if(buyer != null){
                    itemSold.add(i);;
                    seller.sell(i);
                    buyer.buy(i);

                    System.out.println("Auction Item " + i.getName() + " Sold to bidder: " + buyer.getName());

                    Sale s = new Sale(i,buyer,currentDate);
                    s.setDeliveryDate(deliverydate);
                    sales.add(s);
                }else{
                    seller.getAvailableItems().remove(i);
                }
            }
        }
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        calculations();
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

    }
    public void addDays(Administrator user, LocalDate deliverydate, int days){
        currentDate = currentDate.plusDays(days);
        manageAuctions(user,deliverydate);
    }

    //MAIN
    public static void main(String[] args) {
        //DECLARE LINKED LISTS
        OnlineStore os = new OnlineStore(LocalDate.of(2020,11,24));

        //CREATE USERS AS USERS TO DEMONSTRATE CASTING AMONG SUBCLASSES
        User Jordi = new Buyer("Jordi", "42069","halo","117117");
        os.users.add(Jordi);
        System.out.println("Added User " + Jordi.getName() + " with id " + Jordi.getID() + " to the online store.");

        User Cristy = new Buyer("Cristy", "24624", "hamilton", "999999");
        os.users.add(Cristy);
        System.out.println("Added User " + Cristy.getName() + " with id " + Cristy.getID() + " to the online store.");

        User Eric = new Administrator("Eric", "69420","martaloverxd");
        os.users.add(Eric);
        System.out.println("Added User " + Eric.getName() + " with id " + Eric.getID() + " to the online store.");

        User Helena = new Seller("Helena", "012001","queen","666666");
        os.users.add(Helena);
        System.out.println("Added User " + Helena.getName() + " with id " + Helena.getID() + " to the online store.");

        User Klaus = new Seller("Klaus", "051101","hohoho","002512");
        os.users.add(Klaus);
        System.out.println("Added User " + Klaus.getName() + " with id " + Klaus.getID() + " to the online store.");

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //ADMINISTRATOR ERIC EXPELS USER KLAUS AND PRINT THE AUCTION ITEMS STOCK
        ((Administrator) Eric).expel(((os.users.get(os.users.indexOf(Klaus)))),os.users);
        ((Administrator) Eric).printStock(os.auctionItems);

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CREATE PACKAGES
        Package Box1 = new Box(19,21,15);
        os.packages.add(Box1);
        System.out.println("Added Box with dimensions: " + Box1.getHeight() + ", " + Box1.getWidth() + ", " + ((Box) Box1).getDepth());

        Package Box2 = new Box(40,40,30);
        os.packages.add(Box2);
        System.out.println("Added Box with dimensions: " + Box2.getHeight() + ", " + Box2.getWidth() + ", " + ((Box) Box2).getDepth());

        Package Box3 = new Box(100,200,50);
        os.packages.add(Box3);
        System.out.println("Added Box with dimensions: " + Box3.getHeight() + ", " + Box3.getWidth() + ", " + ((Box) Box3).getDepth());

        Package A5 = new Envelope(21,11, "A5");
        os.packages.add(A5);
        System.out.println("Added Envelope of name: " + ((Envelope) A5).getName() + " with dimensions: " + A5.getHeight() + ", " + A5.getWidth());

        Package A4 = new Envelope(21,29, "A4");
        os.packages.add(A4);
        System.out.println("Added Envelope of name: " + ((Envelope) A4).getName() + " with dimensions: " + A4.getHeight() + ", " + A4.getWidth());

        Package A3 = new Envelope(29,42, "A3");
        os.packages.add(A3);
        System.out.println("Added Envelope of name: " + ((Envelope) A3).getName() + " with dimensions: " + A3.getHeight() + ", " + A3.getWidth());

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CREATE ITEMS AND ASSIGN BEST PACKAGE
        Item HamiltonNovel = new UnitItem("Hamilton Novel","Book",new double[]{20,28},1,40,50 );
        System.out.println("Added " + ((UnitItem) HamiltonNovel).getQuantity() + " Units of Item " + HamiltonNovel.getName() + " of type " + HamiltonNovel.getType() + " with a price of " + ((UnitItem) HamiltonNovel).getUnitPrice() + " each to the online store.");
        HamiltonNovel.assignBestPackage(os.packages);
        os.itemAvailable.add(HamiltonNovel);

        Item Halo = new UnitItem("Halo","Game",new double[]{21,32},5,30,10000 );
        System.out.println("Added " + ((UnitItem) Halo).getQuantity() + " Units of Item " + Halo.getName() + " of type " + Halo.getType() + " with a price of " + ((UnitItem) Halo).getUnitPrice() + " each to the online store.");
        Halo.assignBestPackage(os.packages);
        os.itemAvailable.add(Halo);

        Item Potato = new WeightedItem("Potato","Food",new double[]{10,20,10},0.5,2,5000 );
        System.out.println("Added " + ((WeightedItem) Potato).getWeight() + " Weights of Item " + Potato.getName() + " of type " + Potato.getType() + " with a price of " + ((WeightedItem) Potato).getPricePerWeight() + " each weight to the online store.");
        Potato.assignBestPackage(os.packages);
        os.itemAvailable.add(Potato);

        Item Ericclone = new AuctionItem("Eric","Gamer",new double[]{50,181,30},0.1,20,LocalDate.of(2001,03,20));
        System.out.println("Added Auction Item " + Ericclone.getName() + " of type " + Ericclone.getType() + " with a starting price of " + Ericclone.getPrice() + " to the online store with the deadline: " + ((AuctionItem) Ericclone).getDeadline() + ".");
        Ericclone.assignBestPackage(os.packages);
        os.itemAvailable.add(Ericclone);
        os.auctionItems.add((AuctionItem) Ericclone);

        Item OldLaptop = new AuctionItem("Old Laptop","Laptop",new double[]{31,22,20},100,500,LocalDate.of(2020,11,30) );
        System.out.println("Added Auction Item " + OldLaptop.getName() + " of type " + OldLaptop.getType() + " with a starting price of " + OldLaptop.getPrice() + " to the online store with the deadline: " + ((AuctionItem) OldLaptop).getDeadline() + ".");
        OldLaptop.assignBestPackage(os.packages);
        os.itemAvailable.add(OldLaptop);
        os.auctionItems.add((AuctionItem) OldLaptop);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        os.sortlists((Administrator) Eric);

        //ADDING ALL ITEMS FOR SALE TO THE ONLY SELLER: HELENA
        ((Seller)Helena).addAvailableItem(Halo);
        ((Seller)Helena).addAvailableItem(HamiltonNovel);
        ((Seller)Helena).addAvailableItem(Potato);
        ((Seller)Helena).addAvailableItem(Ericclone);
        ((Seller)Helena).addAvailableItem(OldLaptop);

        //CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        os.calculations();
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");


        //ADD 0 DAYS TO CURRENTDAYS AND MANAGE AUCTION ITEMS (24/11/2020) WITH A DELIVERY DATE OF (25/11/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        os.addDays(((Administrator)Eric),LocalDate.of(2020,11,25), 0);

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        os.sortlists(((Administrator)Eric));

        //USER JORDI BUYS ITEM HALO FROM HELENA ON (24/11/2020) WITH A DELIVERY DATE OF (25/11/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        os.sell(((Buyer)Jordi),((Seller)Helena),Halo,LocalDate.of(2020,11,25));

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        os.sortlists(((Administrator)Eric));

        //USER CRISTY BUYS ITEM HAMILTON NOVEL FROM HELENA ON (24/11/2020) WITH A DELIVERY DATE OF (25/11/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        os.sell(((Buyer)Cristy), ((Seller)Helena),HamiltonNovel,LocalDate.of(2020,11,25));

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        os.sortlists(((Administrator)Eric));

        //USER JORDI BUYS ITEM POTATO FROM HELENA ON (24/11/2020) WITH A DELIVERY DATE OF (25/11/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        os.sell(((Buyer)Jordi), ((Seller)Helena),Potato,LocalDate.of(2020,11,25));


        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        os.sortlists(((Administrator)Eric));

        //USER JORDI MAKES BID ON OLD LAPTOP
        ((AuctionItem)OldLaptop).makeBid(((Buyer)Jordi),900);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //ADD 0 DAYS TO CURRENTDAYS AND MANAGE AUCTION ITEMS (24/11/2020) WITH A DELIVERY DATE OF (25/11/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        os.addDays(((Administrator)Eric),LocalDate.of(2020,11,25), 0);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        os.sortlists(((Administrator)Eric));

        //ADD 7 DAYS TO CURRENTDAYS AND MANAGE AUCTION ITEMS (01/12/2020) WITH A DELIVERY DATE OF (04/12/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        os.addDays(((Administrator)Eric),LocalDate.of(2020,12,4), 7);

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        os.sortlists(((Administrator)Eric));
    }
}
