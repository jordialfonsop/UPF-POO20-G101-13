import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;

public class OnlineStore {
    //ATTRIBUTES
    private static LinkedList<User> users;
    private static LinkedList<Item> itemSold;
    private static LinkedList<Item> itemAvailable;
    private static LinkedList<AuctionItem> auctionItems;
    private static LinkedList<Package> packages;
    private static LinkedList<Sale> sales;
    private static double totalPrice = 0;
    private static double totalProfit = 0;
    private static double totalTaxes = 0;

    //METHODS
    public static void calculatePrice(LinkedList<Item> itemAvailable){
        totalPrice = 0;
        for (int i = 0; i < itemAvailable.size();i++){
            totalPrice += itemAvailable.get(i).getPricePlusTax();
        }
        System.out.println("Total Price: " + totalPrice);
    }
    public static void calculateProfit(LinkedList<Item> itemSold){
        totalProfit = 0;
        for (int i = 0; i < itemSold.size();i++){
            totalProfit += itemSold.get(i).calculateProfit();
        }
        System.out.println("Total Profit: " + totalProfit);
    }
    public static void calculateTaxes(LinkedList<Item> itemSold){
        totalTaxes = 0;
        for (int i = 0; i < itemSold.size(); i++){
            double temp = itemSold.get(i).sumTotalTax(itemSold.get(i).getPack());
            totalTaxes += temp;
        }
        System.out.println("Total Taxes: " + totalTaxes);
    }
    public static void calculations(LinkedList<Item> itemSold,LinkedList<Item> itemAvailable){
        calculatePrice(itemAvailable);
        calculateProfit(itemSold);
        calculateTaxes(itemSold);
        }
    public static void sortlists(LinkedList<Item> itemSold,LinkedList<Item> itemAvailable,LinkedList<AuctionItem> auctionItems,LinkedList<Sale> sales, Administrator admin){

        Collections.sort(itemAvailable);
        System.out.println("Currently available items: ");
        for (int i = 0; i < itemAvailable.size(); i++) {
            System.out.println(itemAvailable.get(i).getName());
        }
        System.out.println("");

        Collections.sort(itemSold);
        System.out.println("Currently sold items: ");
        for (int i = 0; i < itemSold.size(); i++) {
            System.out.println(itemSold.get(i).getName());
        }
        System.out.println("");

        Collections.sort(sales);
        System.out.println("Current sales: ");
        for (int i = 0; i < sales.size(); i++) {
            sales.get(i).printInfo();
        }
        System.out.println("");

        Collections.sort(auctionItems);
        admin.printStock(auctionItems);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

    }
    public static void manageAuctions(Administrator user, LinkedList<AuctionItem> auctionItems, LinkedList<Item> itemSold,LinkedList<Item> itemAvailable,LinkedList<User> users, LinkedList<Sale> sales, Date d, Date deliverydate){
        for (int i = 0; i < auctionItems.size(); i++){
            if(user.manageAuction(auctionItems.get(i),d)){
                itemAvailable.remove(auctionItems.get(i));
                for (int j = 0; j < users.size(); j++){
                    if((users.get(j) instanceof Seller)){
                        sell(itemSold,itemAvailable,auctionItems.get(i).getBidder(), (Seller) users.get(j),auctionItems.get(i),sales,d,deliverydate);
                    }
                }
                auctionItems.remove(i);
            }
        }
    }
    public static void sell(LinkedList<Item> itemSold,LinkedList<Item> itemAvailable, Buyer buyer,Seller seller, Item i, LinkedList<Sale> sales, Date date, Date deliverydate){
        if((seller != null) && (seller.getAvailableItems().contains(i))){
            if((i instanceof UnitItem) || (i instanceof WeightedItem)){
                if(buyer != null){
                    itemAvailable.remove(i);
                    itemSold.add(i);

                    seller.sell(i);
                    buyer.buy(i);

                    System.out.println("Buyer " + buyer.getName() + " bought item " + i.getName() + " from seller " + seller.getName());

                    Sale s = new Sale(i,buyer,date);
                    s.setDeliveryDate(deliverydate);
                    sales.add(s);
                }
            }else{
                if(buyer != null){
                    itemSold.add(i);;
                    seller.sell(i);
                    buyer.buy(i);

                    System.out.println("Auction Item " + i.getName() + " Sold to bidder: " + buyer.getName());

                    Sale s = new Sale(i,buyer,date);
                    s.setDeliveryDate(deliverydate);
                    sales.add(s);
                }else{
                    seller.getAvailableItems().remove(i);
                }
            }
        }
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        calculations(itemSold, itemAvailable);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

    }

    //MAIN
    public static void main(String[] args) {
        //DECLARE LINKED LISTS
        itemAvailable = new LinkedList< Item >();
        itemSold = new LinkedList< Item >();
        auctionItems = new LinkedList< AuctionItem>();
        users = new LinkedList< User >();
        packages = new LinkedList< Package >();
        sales = new LinkedList< Sale >();

        //CREATE USERS
        User Jordi = new Buyer("Jordi", "42069","halo","117117");
        users.add(Jordi);
        System.out.println("Added User " + Jordi.getName() + " with id " + Jordi.getID() + " to the online store.");

        User Cristy = new Buyer("Cristy", "24624", "hamilton", "999999");
        users.add(Cristy);
        System.out.println("Added User " + Cristy.getName() + " with id " + Cristy.getID() + " to the online store.");

        User Eric = new Administrator("Eric", "69420","martaloverxd");
        users.add(Eric);
        System.out.println("Added User " + Eric.getName() + " with id " + Eric.getID() + " to the online store.");

        User Helena = new Seller("Helena", "012001","queen","666666");
        users.add(Helena);
        System.out.println("Added User " + Helena.getName() + " with id " + Helena.getID() + " to the online store.");

        User Klaus = new Seller("Klaus", "051101","hohoho","002512");
        users.add(Klaus);
        System.out.println("Added User " + Klaus.getName() + " with id " + Klaus.getID() + " to the online store.");

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //ADMINISTRATOR ERIC EXPELS USER KLAUS AND PRINT THE AUCTION ITEMS STOCK
        ((Administrator) Eric).expel(Klaus,users);
        ((Administrator) Eric).printStock(auctionItems);

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CREATE PACKAGES
        Package Box1 = new Box(19,21,15);
        packages.add(Box1);
        System.out.println("Added Box with dimensions: " + Box1.getHeight() + ", " + Box1.getWidth() + ", " + ((Box) Box1).getDepth());

        Package Box2 = new Box(40,40,30);
        packages.add(Box2);
        System.out.println("Added Box with dimensions: " + Box2.getHeight() + ", " + Box2.getWidth() + ", " + ((Box) Box2).getDepth());

        Package Box3 = new Box(100,200,50);
        packages.add(Box3);
        System.out.println("Added Box with dimensions: " + Box3.getHeight() + ", " + Box3.getWidth() + ", " + ((Box) Box3).getDepth());

        Package A5 = new Envelope(21,11, "A5");
        packages.add(A5);
        System.out.println("Added Envelope of name: " + ((Envelope) A5).getName() + " with dimensions: " + A5.getHeight() + ", " + A5.getWidth());

        Package A4 = new Envelope(21,29, "A4");
        packages.add(A4);
        System.out.println("Added Envelope of name: " + ((Envelope) A4).getName() + " with dimensions: " + A4.getHeight() + ", " + A4.getWidth());

        Package A3 = new Envelope(29,42, "A3");
        packages.add(A3);
        System.out.println("Added Envelope of name: " + ((Envelope) A3).getName() + " with dimensions: " + A3.getHeight() + ", " + A3.getWidth());

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CREATE ITEMS AND ASSIGN BEST PACKAGE
        Item HamiltonNovel = new UnitItem("Hamilton Novel","Book",new double[]{20,28},1,40,50 );
        itemAvailable.add(HamiltonNovel);
        System.out.println("Added " + ((UnitItem) HamiltonNovel).getQuantity() + " Units of Item " + HamiltonNovel.getName() + " of type " + HamiltonNovel.getType() + " with a price of " + ((UnitItem) HamiltonNovel).getUnitPrice() + " each to the online store.");
        HamiltonNovel.assignBestPackage(packages);

        Item Halo = new UnitItem("Halo","Game",new double[]{21,32},5,30,10000 );
        itemAvailable.add(Halo);
        System.out.println("Added " + ((UnitItem) Halo).getQuantity() + " Units of Item " + Halo.getName() + " of type " + Halo.getType() + " with a price of " + ((UnitItem) Halo).getUnitPrice() + " each to the online store.");
        Halo.assignBestPackage(packages);

        Item Potato = new WeightedItem("Potato","Food",new double[]{10,20,10},0.5,2,5000 );
        itemAvailable.add(Potato);
        System.out.println("Added " + ((WeightedItem) Potato).getWeight() + " Weights of Item " + Potato.getName() + " of type " + Potato.getType() + " with a price of " + ((WeightedItem) Potato).getPricePerWeight() + " each weight to the online store.");
        Potato.assignBestPackage(packages);

        Item Ericclone = new AuctionItem("Eric","Gamer",new double[]{50,181,30},0.1,20, new Date(2001, 3, 20));
        itemAvailable.add(Ericclone);
        auctionItems.add((AuctionItem) Ericclone);
        System.out.println("Added Auction Item " + Ericclone.getName() + " of type " + Ericclone.getType() + " with a starting price of " + Ericclone.getPrice() + " to the online store with the deadline: " + ((AuctionItem) Ericclone).getDeadline() + ".");
        Ericclone.assignBestPackage(packages);

        Item OldLaptop = new AuctionItem("Old Laptop","Laptop",new double[]{31,22,20},100,500,new Date(2020, 11, 30) );
        itemAvailable.add(OldLaptop);
        auctionItems.add((AuctionItem) OldLaptop);
        System.out.println("Added Auction Item " + OldLaptop.getName() + " of type " + OldLaptop.getType() + " with a starting price of " + OldLaptop.getPrice() + " to the online store with the deadline: " + ((AuctionItem) OldLaptop).getDeadline() + ".");
        OldLaptop.assignBestPackage(packages);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        sortlists(itemSold,itemAvailable,auctionItems,sales, ((Administrator)Eric));

        //ADDING ALL ITEMS FOR SALE TO THE ONLY SELLER: HELENA
        ((Seller)Helena).addAvailableItem(Halo);
        ((Seller)Helena).addAvailableItem(HamiltonNovel);
        ((Seller)Helena).addAvailableItem(Potato);
        ((Seller)Helena).addAvailableItem(Ericclone);
        ((Seller)Helena).addAvailableItem(OldLaptop);

        //CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        calculations(itemSold,itemAvailable);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");


        //MANAGE AUCTION ITEMS (24/11/2020) WITH A DELIVERY DATE OF (25/11/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        manageAuctions((Administrator) Eric, auctionItems, itemSold, itemAvailable, users,sales,new Date(2020, 11, 24),new Date(2020, 11, 25));

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        sortlists(itemSold,itemAvailable,auctionItems,sales, ((Administrator)Eric));

        //USER JORDI BUYS ITEM HALO FROM HELENA ON (24/11/2020) WITH A DELIVERY DATE OF (25/11/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        sell(itemSold,itemAvailable, ((Buyer)Jordi), ((Seller)Helena),Halo,sales,new Date(2020, 11, 24),new Date(2020, 11, 25));

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        sortlists(itemSold,itemAvailable,auctionItems,sales, ((Administrator)Eric));

        //USER CRISTY BUYS ITEM HAMILTON NOVEL FROM HELENA ON (24/11/2020) WITH A DELIVERY DATE OF (25/11/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        sell(itemSold,itemAvailable, ((Buyer)Cristy), ((Seller)Helena),HamiltonNovel,sales,new Date(2020, 11, 24),new Date(2020, 11, 25));

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        sortlists(itemSold,itemAvailable,auctionItems,sales, ((Administrator)Eric));

        //USER JORDI BUYS ITEM POTATO FROM HELENA ON (24/11/2020) WITH A DELIVERY DATE OF (25/11/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        sell(itemSold,itemAvailable, ((Buyer)Jordi), ((Seller)Helena),Potato,sales,new Date(2020, 11, 24),new Date(2020, 11, 25));

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        sortlists(itemSold,itemAvailable,auctionItems,sales, ((Administrator)Eric));

        //USER JORDI MAKES BID ON OLD LAPTOP
        ((AuctionItem) OldLaptop).makeBid((Buyer) Jordi,600);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //MANAGE AUCTION ITEMS (24/11/2020) WITH A DELIVERY DATE OF (25/11/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        manageAuctions((Administrator) Eric, auctionItems, itemSold, itemAvailable, users,sales,new Date(2020, 11, 24),new Date(2020, 11, 25));
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        sortlists(itemSold,itemAvailable,auctionItems,sales, ((Administrator)Eric));

        //MANAGE AUCTION ITEMS (01/12/2020) WITH A DELIVERY DATE OF (04/12/2020) + CALCULATE TOTAL PRICE, TOTAL PROFIT AND TOTAL TAXES
        manageAuctions((Administrator) Eric, auctionItems, itemSold, itemAvailable, users,sales,new Date(2020, 12, 01),new Date(2020, 12, 04));

        //SORT LISTS AND PRINT THEM (AUCTION ITEMS REQUIRES ADMIN)
        sortlists(itemSold,itemAvailable,auctionItems,sales, ((Administrator)Eric));
    }
}
