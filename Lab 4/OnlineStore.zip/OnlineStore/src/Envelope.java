public class Envelope extends Package {
    //ATTRIBUTES
    private String name;

    //CONSTRUCTOR
    public Envelope(int w, int h, String n) {
        super(w,h);
        setName(n);
    }

    //GETTERS
    public String getName() {
        return name;
    }
    @Override
    public double getPrice() {
        return getCostPerCm2() * 2 * getHeight() * getWidth();
    }
    public double getPriceOnlyTax(){
        return getPrice() * percentageIVA;
    }
    public double getPricePlusTax(){
        return getPrice() + getPriceOnlyTax();
    }

    //SETTERS
    public void setName(String name) {
        this.name = name;
    }

    //METHODS
    @Override
    public boolean isSuitable(double[] size){
        if(size.length==2){
            if(size[0]<=getWidth() && size[1]<= getHeight()){
                return true;
            }
        }
        return false;
    }
    @Override
    public double sumTotalTax(Taxable t) {
        return getPriceOnlyTax() + t.getPriceOnlyTax();
    }

    @Override
    public String printInfo(){
        return ("Envelope of name: " + getName() + " with dimensions: " + getHeight() + ", " + getWidth());
    }
}