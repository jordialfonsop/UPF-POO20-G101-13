public class User {
    private String name;
    private String identifier;
    private String password;

    //CONSTRUCTOR
    public User(String n, String id, String pass) {
        this.name = n;
        this.identifier = id;
        this.password = pass;
    }

    //GETTERS
    public String getName() {
        return name;
    }
    public String getID() {
        return identifier;
    }
    public String getPassword() {
        return password;
    }

    //SETTERS
    public void setName(String n) {
        this.name = n;
    }

    //METHODS
    public boolean login(String p){
        return this.password.equals(p);
    }
}