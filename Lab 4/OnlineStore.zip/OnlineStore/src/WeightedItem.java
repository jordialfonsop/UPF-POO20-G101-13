import java.util.Date;

public class WeightedItem extends Item {
    //ATTRIBUTES
    private double pricePerWeight;
    private double weight;
    private double weightRemaining;

    //CONSTRUCTOR
    public WeightedItem(String name, String type, double[] size, double cost,double wprice, double w) {
        super(name, type, size, cost);
        this.pricePerWeight = wprice;
        this.weight = w;
        this.weightRemaining = weight;
    }

    //GETTERS
    @Override
    public double getPrice(){
            return pricePerWeight * weightRemaining;
    }
    public double getPriceOnlyTax(){
        return (getPrice() * percentageIVA);
    }
    public double getPricePlusTax(){
        return (getPrice() + getPriceOnlyTax());
    };
    public double getWeight(){
        return weight;
    }
    public double getPricePerWeight(){
        return pricePerWeight;
    }

    //METHODS
    @Override
    public double calculateProfit(){
        if(weight-weightRemaining == 0){
            return (((pricePerWeight-getCost()) * weight) - getPriceOnlyTax()) - getPack().getPricePlusTax();
        }else{
            return ((pricePerWeight-getCost()) * (weight-weightRemaining) - getPriceOnlyTax()) - getPack().getPricePlusTax();
        }
    }
    @Override
    public double sumTotalTax(Taxable t) {
        return getPriceOnlyTax() + t.getPriceOnlyTax();
    }
    public double sell(double w){
        if (weightRemaining >= w){
            this.weightRemaining = this.weightRemaining - w;
            return w*pricePerWeight;
        }
        return 0;
    }

    @Override
    public int compareTo(Item o) {
        return Double.compare(getPrice(), o.getPrice());
    }
}
