public abstract class Package implements Taxable{
    //ATTRIBUTES
    private int width;
    private int height;
    private static final double costPerCm2 = 0.5;

    //CONSTRUCTOR
    public Package(int w, int h) {
        setWidth(w);
        setHeight(h);
    }

    //GETTERS
    public int getWidth() {
        return width;
    }
    public int getHeight() { return height; }
    public double getCostPerCm2(){
        return costPerCm2;
    }
    public abstract double getPrice();
    public abstract double getPriceOnlyTax();
    public abstract double getPricePlusTax();

    //SETTERS
    public void setWidth(int w) {
        this.width = w;
    }
    public void setHeight(int h) {
        this.height = h;
    }

    //METHODS
    public abstract boolean isSuitable(double[] size);
    public abstract double sumTotalTax(Taxable t);
    public abstract String printInfo();
}
