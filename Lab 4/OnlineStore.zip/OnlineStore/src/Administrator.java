import java.time.LocalDate;
import java.util.LinkedList;

public class Administrator extends User {
    //CONSTRUCTOR
    public Administrator(String n, String id, String pass) {
        super(n, id, pass);
    }

    //METHODS
    public void printStock(LinkedList<AuctionItem> items){
        System.out.println("Current Auction Stock:");
        if(items.size() == 0){
            System.out.println("Empty");
        }
        for (int i = 0; i < (items.size());i++){
            System.out.println("Item " + i + ": Name: " + items.get(i).getName() + ", " + "Type: " + items.get(i).getType() + ", " + "Cost: " + items.get(i).getCost() + ", " + "Price: " + items.get(i).getPrice() + ", " + "Deadline: " + items.get(i).getDeadline());

        }
    }
    public boolean expel(User u,LinkedList<User> user_list){
        System.out.println("Administrator " + getName() + " with id " + getID() + " has expelled user " + u.getName() + " with id " + u.getID() + " from the online store");
        return user_list.remove(u);
    }
    public boolean manageAuction(AuctionItem a, LocalDate date){
        if (a.frozen(date)){
            System.out.println("Auction Item " + a.getName() + " Managed");
        }else{
            System.out.println("Auction Item " + a.getName() + " not Managed");
        }
        return a.frozen(date);
    }
}
