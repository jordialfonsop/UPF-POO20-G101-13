import java.util.Date;

public class AuctionItem extends Item {
    //ATTRIBUTES
    private double currentPrice;
    private Buyer bidder;
    private Date deadline;
    private static final int fixed_fee = 5;
    private static final double percentagefee = 0.05;

    //CONSTRUCTOR
    public AuctionItem(String name, String type, double[] size, double cost, double startingPrice, Date deadline) {
        super(name, type, size, cost);
        this.currentPrice = startingPrice;
        this.deadline = deadline;
    }

    //GETTERS
    public Buyer getBidder() {
        return bidder;
    }
    public Date getDeadline() {
        return deadline;
    }
    @Override
    public double getPrice() {
        return currentPrice;
    }
    public double getPriceOnlyTax(){
        return ((getPrice() * percentageIVA) + fixed_fee + (getPrice()*percentagefee));
    }
    public double getPricePlusTax(){
        return (getPrice() + getPriceOnlyTax());
    }

    //METHODS
    public void makeBid(Buyer b, double p){
        System.out.println("Buyer " + b.getName() + " has introduced a higher bid for item " + getName() + " with a price of " + p + ".");
        this.currentPrice = p;
        this.bidder = b;
    }
    public boolean frozen(Date d){
        return d.after(getDeadline());
    }
    @Override
    public double calculateProfit(){
        return (getPrice()-getCost()) - fixed_fee - ((getPrice())*(percentagefee)) - getPriceOnlyTax();
    }
    @Override
    public double sumTotalTax(Taxable t) {
        return getPriceOnlyTax() + t.getPriceOnlyTax();
    }
    @Override
    public int compareTo(Item o) {
        return Double.compare(getPrice(), o.getPrice());
    }
}
