import java.util.LinkedList;

public class Seller extends User{
    //ATTRIBUTES
    private String accountNumber;
    private LinkedList<Item> soldItems;
    private LinkedList<Item> availableItems;

    //CONSTRUCTOR
    public Seller(String n, String id, String pass, String a) {
        super(n, id, pass);
        this.accountNumber = a;
        soldItems = new LinkedList<Item>();
        availableItems = new LinkedList<Item>();
    }

    //GETTERS
    public LinkedList<Item> getAvailableItems(){
        return availableItems;
    }

    //METHODS
    public void sell(Item i){
        deposit(i.getPrice() - i.getPriceOnlyTax());
        soldItems.add(i);
        availableItems.remove(i);
    }
    public void addAvailableItem(Item i){
        availableItems.add(i);
    }
    private boolean deposit(double price){
        System.out.println(price + " deposited to account number: " + accountNumber);
        return true;
    }
}
