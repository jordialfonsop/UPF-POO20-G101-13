import java.util.LinkedList;

public class Buyer extends User {
    //ATTRIBUTES
    private String accountNumber;
    private LinkedList<Item> boughtItems;

    //CONSTRUCTOR
    public Buyer(String n, String id, String pass, String a) {
        super(n, id, pass);
        this.accountNumber = a;
        boughtItems = new LinkedList<Item>();
    }

    //METHODS
    public void buy(Item i){
        pay(i.getPrice());
        boughtItems.add(i);
    }
    //PENDING
    private boolean pay(double price){
        System.out.println(price + " deducted from account number: " + accountNumber);
        return true;
    }
}
