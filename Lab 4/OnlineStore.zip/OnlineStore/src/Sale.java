import java.util.Date;

public class Sale implements Comparable<Sale> {
    //ATTRIBUTES
    private Item item;
    private Buyer buyer;
    private Date date;
    private Date deliveryDate;

    //CONSTRUCTOR
    public Sale(Item i, Buyer b, Date d){
        this.item = i;
        this.buyer = b;
        this.date = d;
    }

    //GETTERS
    public Item getItem() {
        return item;
    }
    public Buyer getBuyer() {
        return buyer;
    }
    public Date getDate() {
        return date;
    }
    public Date getDeliveryDate() {
        return deliveryDate;
    }

    //SETTERS
    public void setDeliveryDate(Date deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    //METHODS
    @Override
    public int compareTo(Sale o) {
        return getDate().compareTo(o.getDate());
    }
    public void printInfo(){
        System.out.println("ITEM: " + getItem().getName() + ", BUYER: " + getBuyer().getName() + ", ACQUISITION DATE: " + getDate() + ", DELIVERY DATE: " + getDeliveryDate());
    }

}
