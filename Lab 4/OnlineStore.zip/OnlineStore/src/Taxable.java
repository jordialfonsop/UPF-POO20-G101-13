public interface Taxable {
    //ATTRIBUTES
    static final double percentageIVA = 0.21;

    //METHODS
    double getPrice();
    double getPriceOnlyTax();
    double getPricePlusTax();
    double sumTotalTax( Taxable t );

}