public class Box extends Package {
    //ATTRIBUTES
    private int depth;

    //CONSTRUCTOR
    public Box(int w, int h, int d) {
        super(w,h);
        setDepth(d);
    }

    //GETTERS
    public int getDepth() {
        return depth;
    }
    public double getPriceOnlyTax(){
        return getPrice() * percentageIVA;
    }
    public double getPricePlusTax(){
        return getPrice() + getPriceOnlyTax();
    }
    @Override
    public double getPrice() {
        return getCostPerCm2() * (2*((getHeight() * getWidth()) + (getHeight() * getDepth()) + (getWidth() * getDepth())));
    }

    //SETTERS
    public void setDepth(int depth) {
        this.depth = depth;
    }

    //METHODS
    @Override
    public boolean isSuitable(double[] size){
        if(size.length == 3){
            if(size[0]<=getWidth() && size[1]<=getHeight() && size[2]<=getDepth()){
                return true;
            }
        }
        return false;
    }
    @Override
    public double sumTotalTax(Taxable t) {
        return getPriceOnlyTax() + t.getPriceOnlyTax();
    }
    @Override
    public String printInfo(){
        return ("Box with dimensions: " + getHeight() + ", " + getWidth() + ", " + getDepth());
    }
}
