import java.awt.Graphics;

public class Logo {
    //ATTRIBUTES
    private int width;
    private int height;
    private Turtle t;
    
    //CONSTRUCTOR
    public Logo(int w, int h){
        width = w;
        height = h;
        t = new Turtle(w/2,h/2,0,1);
    }
    
    //GETTERS
    public int getWidth(){
        return width;
    }
    public int getHeight(){
        return height;
    }
    
    //METHODS
    public void resetTurtle(){
        t.setX(width/2);
        t.setY(height/2);
        t.setDirX(0);
        t.setDirY(1);
    }
    public void execute(Program p, Graphics g){
        resetTurtle();
        if (p.isCorrect()){
            p.restart();
            while (!p.hasFinished()) {
                Instruction instr = p.getNextInstruction();
                switch (instr.getCode()){
                    case "PEN":
                        t.setPen(!t.isPenOn());
                        break;
                    case "FWD":
                        t.forward(instr.getParam(), g);
                        break;
                    case "ROT":
                        t.turn(instr.getParam());
                        break;
                }
            }
            p.printErrors();
        }
    }
    
}
