import java.util.LinkedList;

public class Program {
    //ATTRIBUTES
    private int currentLine;
    private LinkedList<Instruction> instructions;
    private int loopIteration;
    private String programName;
    
    //CONSTRUCTOR
    public Program(String name){
        programName = name;
        currentLine = 0;
        loopIteration = 1;
        instructions = new LinkedList<Instruction>();
    }

    //GETTERS
    public String getName(){
        return programName;
    }

    //METHODS
    private void goToStartLoop(){
        loopIteration++;
        for (int i = 0; i < instructions.size(); i++) {
            if (instructions.get(i).getCode().equals("REP")) {
                currentLine = i;
                instructions.get(currentLine);
            }
        }
    }
    public Instruction getNextInstruction(){
        Instruction nextInstruction = instructions.get(currentLine);
        
        Boolean existsRep = false;
        Integer position = null;
        for (int i = 0; i < instructions.size(); i++) {
            if (instructions.get(i).getCode().equals("REP")) {
                existsRep = true;
                position = i;
            }
        } 

        
        if (existsRep) {
            Double aux = instructions.get(position).getParam();
            Integer loops = aux.intValue();
            
            if (existsRep && (instructions.get(currentLine).getCode().equals("END") && (loopIteration != Math.round(loops)))) {
                goToStartLoop();
                return nextInstruction; 
            }
        }
                           
        currentLine++;
        return nextInstruction;
    }
    public boolean addInstruction(String c, double p){
        Instruction i = new Instruction(c,p);
        instructions.add(i);
        return i.isCorrect();
    }
    public boolean hasFinished(){
        Boolean existsRep = false;
        Integer position = null;
        
        for (int i = 0; i < instructions.size(); i++) {
            if (instructions.get(i).getCode().equals("REP") ) {
                existsRep = true;
                position = i;
            }
        }
                   
        if (existsRep && "END".equals(instructions.getLast().getCode())) {
            Double aux = instructions.get(position).getParam();
            Integer loops = aux.intValue();
            return ("END".equals(instructions.get(currentLine).getCode()) && (loopIteration == Math.round(loops)));
        } else {
            return (currentLine == instructions.size()-1);
        }
    }
    public void restart(){
        currentLine = 0;
        loopIteration = 1;
        instructions.getFirst();
    }
    public boolean isCorrect(){
        Boolean repEnd = true;
        
        for (int i = 0; i < instructions.size(); i++) {
            if (!instructions.get(i).isCorrect()) {            
                return false;
            }
            if ("REP".equals(instructions.get(i).getCode())) {               
                repEnd = false;
            } else if ("END".equals(instructions.get(i).getCode())) { 
                repEnd = true;
            }
        }
        
        return repEnd;
    }
    public void printErrors(){
        switch(instructions.get(currentLine).errorCode()){
            case 1:
                System.out.println("FWD instruction parameter in line " + currentLine + " is out of boundaries" );
            case 2:
                System.out.println("PEN instruction parameter in line " + currentLine + " is neither 0 or 1" );
            case 3:
                System.out.println("ROT instruction parameter in line " + currentLine + " is out of boundaries" );
            case 4:
                System.out.println("REP instruction parameter in line " + currentLine + " is out of boundaries" );
        }
    }
}
