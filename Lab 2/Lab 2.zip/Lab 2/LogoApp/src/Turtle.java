import java.awt.Graphics;

public class Turtle {
    //ATTRIBUTES
    private int x;
    private int y;
    private double dirX;
    private double dirY;
    private boolean pen;

    //CONSTRUCTOR
    public Turtle(int x, int y, double dirX, double dirY){
        this.x = x;
        this.y = y;
        this.dirX = dirX;
        this.dirY = dirY;
        this.pen = true;
    }

    //GETTERS
    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }
    public double getDirX() {
        return dirX;
    }
    public double getDirY() {
        return dirY;
    }
    public boolean isPenOn() {
        return pen;
    }

    //SETTERS
    public void setX(int x) {
        this.x = x;
    }
    public void setY(int y) {
        this.y = y;
    }
    public void setDirX(double dirX) {
        this.dirX = dirX;
    }
    public void setDirY(double dirY) {
        this.dirY = dirY;
    }
    public void setCoord(int x, int y){
        setX(x);
        setY(y);
    }
    public void setDir(double dirX, double dirY){
        setDirX(dirX);
        setDirY(dirY);
    }
    public void setPen(boolean state) {
        this.pen = state;
    }

    //METHODS
    public void forward(double distance, Graphics g){
        //Change the position of the turtle in a straight line
        int tempx = getX();
        int tempy = getY();
        setCoord((int) (this.x + Math.round(distance * this.dirX)),(int) (this.y + Math.round(distance * this.dirY)));
        if(isPenOn()) {
            g.drawLine(tempx,tempy,getX(),getY()); 
            draw(g);
        }   
    }
    public void turn(double a){
        //Rotate the turtle
        Double radians = a*Math.PI/180;
        setDir(Math.cos(radians) * (getDirX()) - Math.sin(radians) * (getDirY()),Math.sin(radians) * (getDirX()) + Math.cos(radians) * (getDirY()));
    }
    public void draw(Graphics g){
        int nPoints = 3;
        int[] xc = new int[3];
        int[] yc = new int[3];
        // Declare and Initialize all the necessary variables
        // We set the x and y coordinates in a triangular shape
        xc[0] = (int)(x+8 * dirY);yc[0] = (int)(y-8 * dirX);
        xc[1] = (int)(x-8 * dirY);yc[1] = (int)(y+8 * dirX);
        xc[2] = (int)(x+16 * dirX);yc[2] = (int)(y+16 * dirY);
        // Graphics method to draw a Polygon where the
        // attributes require the x and y coordinates
        // and the number of points
        g.drawPolygon(xc,yc,nPoints);
    }
    
}
