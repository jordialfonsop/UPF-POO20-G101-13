import java.util.Date;
import java.util.LinkedList;

public class OnlineStore {
    //ATTRIBUTES
    private static LinkedList<User> users;
    private static LinkedList<Item> itemSold;
    private static LinkedList<Item> itemAvailable;
    private static LinkedList<AuctionItem> auctionItems;
    private static LinkedList<Package> packages;
    private static double totalPrice = 0;
    private static double totalProfit = 0;

    //METHODS
    public static void calculatePrice(LinkedList<Item> itemAvailable){
        totalPrice = 0;
        for (int i = 0; i < itemAvailable.size();i++){
            totalPrice += itemAvailable.get(i).getPrice();
        }
        System.out.println("Total Price: " + totalPrice);
    }
    public static void calculateProfit(LinkedList<Item> itemSold){
        totalProfit = 0;
        for (int i = 0; i < itemSold.size();i++){
            totalProfit += itemSold.get(i).calculateProfit();
        }
        System.out.println("Total Profit: " + totalProfit);
    }

    public static void manageAuctions(Administrator user,Date d){
        for (int i = 0; i < auctionItems.size(); i++){
            if(user.manageAuction(auctionItems.get(i),d)){
                itemAvailable.remove(auctionItems.get(i));
                if(auctionItems.get(i).getBidder() != null){
                    System.out.println("Auction Item " + auctionItems.get(i).getName() + " Sold to bidder: " + auctionItems.get(i).getBidder().getName());
                    itemSold.add(auctionItems.get(i));
                    auctionItems.get(i).getBidder().buy(auctionItems.get(i));
                    auctionItems.remove(i);
                }
            }
        }
    }


    public static void main(String[] args) {
        //DECLARE LINKED LISTS
        itemAvailable = new LinkedList< Item >();
        itemSold = new LinkedList< Item >();
        auctionItems = new LinkedList< AuctionItem>();
        users = new LinkedList< User >();
        packages = new LinkedList< Package >();

        //CREATE USERS
        User Jordi = new Buyer("Jordi", "42069","halo","117117");
        users.add(Jordi);
        System.out.println("Added User " + Jordi.getName() + " with id " + Jordi.getID() + " to the online store.");

        User Cristy = new Buyer("Cristy", "24624", "hamilton", "999999");
        users.add(Cristy);
        System.out.println("Added User " + Cristy.getName() + " with id " + Cristy.getID() + " to the online store.");

        User Eric = new Administrator("Eric", "69420","martaloverxd");
        users.add(Eric);
        System.out.println("Added User " + Eric.getName() + " with id " + Eric.getID() + " to the online store.");

        User Helena = new Seller("Helena", "012001","queen","666666");
        users.add(Helena);
        System.out.println("Added User " + Helena.getName() + " with id " + Helena.getID() + " to the online store.");

        User Klaus = new Seller("Klaus", "051101","hohoho","002512");
        users.add(Klaus);
        System.out.println("Added User " + Klaus.getName() + " with id " + Klaus.getID() + " to the online store.");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //ADMINISTRATOR ERIC EXPELS USER KLAUS AND PRINT THE AUCTION ITEMS STOCK
        ((Administrator) Eric).expel(Klaus,users);
        ((Administrator) Eric).printStock(auctionItems);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CREATE PACKAGES
        Package Box1 = new Box(19,21,15);
        packages.add(Box1);
        System.out.println("Added Box with dimensions: " + Box1.getHeight() + ", " + Box1.getWidth() + ", " + ((Box) Box1).getDepth());

        Package Box2 = new Box(40,40,30);
        packages.add(Box2);
        System.out.println("Added Box with dimensions: " + Box2.getHeight() + ", " + Box2.getWidth() + ", " + ((Box) Box2).getDepth());

        Package Box3 = new Box(100,200,50);
        packages.add(Box3);
        System.out.println("Added Box with dimensions: " + Box3.getHeight() + ", " + Box3.getWidth() + ", " + ((Box) Box3).getDepth());

        Package A5 = new Envelope(21,11, "A5");
        packages.add(A5);
        System.out.println("Added Envelope of name: " + ((Envelope) A5).getName() + " with dimensions: " + A5.getHeight() + ", " + A5.getWidth());

        Package A4 = new Envelope(21,29, "A4");
        packages.add(A4);
        System.out.println("Added Envelope of name: " + ((Envelope) A4).getName() + " with dimensions: " + A4.getHeight() + ", " + A4.getWidth());

        Package A3 = new Envelope(29,42, "A3");
        packages.add(A3);
        System.out.println("Added Envelope of name: " + ((Envelope) A3).getName() + " with dimensions: " + A3.getHeight() + ", " + A3.getWidth());
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CREATE ITEMS AND ASSIGN BEST PACKAGE
        Item Halo = new UnitItem("Halo","Game",new double[]{21,32},5,30,10000 );
        itemAvailable.add(Halo);
        System.out.println("Added " + ((UnitItem) Halo).getQuantity() + " Units of Item " + Halo.getName() + " of type " + Halo.getType() + " with a price of " + ((UnitItem) Halo).getUnitPrice() + " each to the online store.");
        Halo.assignBestPackage(packages);

        Item HamiltonNovel = new UnitItem("Hamilton Novel","Book",new double[]{20,28},1,40,50 );
        itemAvailable.add(HamiltonNovel);
        System.out.println("Added " + ((UnitItem) HamiltonNovel).getQuantity() + " Units of Item " + HamiltonNovel.getName() + " of type " + HamiltonNovel.getType() + " with a price of " + ((UnitItem) HamiltonNovel).getUnitPrice() + " each to the online store.");
        HamiltonNovel.assignBestPackage(packages);

        Item Potato = new WeightedItem("Potato","Food",new double[]{10,20,10},0.5,2,5000 );
        itemAvailable.add(Potato);
        System.out.println("Added " + ((WeightedItem) Potato).getWeight() + " Weights of Item " + Potato.getName() + " of type " + Potato.getType() + " with a price of " + ((WeightedItem) Potato).getPricePerWeight() + " each weight to the online store.");
        Potato.assignBestPackage(packages);

        Item Ericclone = new AuctionItem("Eric","Gamer",new double[]{50,181,30},0.1,20, new Date(2001, 3, 20));
        itemAvailable.add(Ericclone);
        auctionItems.add((AuctionItem) Ericclone);
        System.out.println("Added Auction Item " + Ericclone.getName() + " of type " + Ericclone.getType() + " with a starting price of " + Ericclone.getPrice() + " to the online store with the deadline: " + ((AuctionItem) Ericclone).getDeadline() + ".");
        Ericclone.assignBestPackage(packages);

        Item OldLaptop = new AuctionItem("Old Laptop","Laptop",new double[]{31,22,20},100,500,new Date(2020, 11, 30) );
        itemAvailable.add(OldLaptop);
        auctionItems.add((AuctionItem) OldLaptop);
        System.out.println("Added Auction Item " + OldLaptop.getName() + " of type " + OldLaptop.getType() + " with a starting price of " + OldLaptop.getPrice() + " to the online store with the deadline: " + ((AuctionItem) OldLaptop).getDeadline() + ".");
        OldLaptop.assignBestPackage(packages);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //PRINT THE AUCTION ITEMS STOCK AND MANAGE THEM (24/11/2020)
        ((Administrator) Eric).printStock(auctionItems);
        manageAuctions((Administrator) Eric, new Date(2020, 11, 24));
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CALCULATE TOTAL PRICE AND TOTAL PROFIT
        calculatePrice(itemAvailable);
        calculateProfit(itemSold);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //USER JORDI BUYS ITEM HALO
        ((Buyer) Jordi).buy(Halo);
        itemSold.add(Halo);
        itemAvailable.remove(Halo);
        System.out.println("User " + Jordi.getName() + " bought item " + Halo.getName() + ".");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CALCULATE TOTAL PRICE AND TOTAL PROFIT
        calculatePrice(itemAvailable);
        calculateProfit(itemSold);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //USER CRISTY BUYS ITEM HAMILTON NOVEL
        ((Buyer) Cristy).buy(HamiltonNovel);
        itemSold.add(HamiltonNovel);
        itemAvailable.remove(HamiltonNovel);
        System.out.println("User " + Cristy.getName() + " bought item " + HamiltonNovel.getName() + ".");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CALCULATE TOTAL PRICE AND TOTAL PROFIT
        calculatePrice(itemAvailable);
        calculateProfit(itemSold);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //USER HELENA SELLS ITEM POTATO
        ((Seller) Helena).addAvailableItem(Potato);
        ((Seller) Helena).sell(Potato);
        itemSold.add(Potato);
        itemAvailable.remove(Potato);
        System.out.println("User " + Helena.getName() + " sold item " + Potato.getName() + ".");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CALCULATE TOTAL PRICE AND TOTAL PROFIT
        calculatePrice(itemAvailable);
        calculateProfit(itemSold);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //USER JORDI MAKES BID ON OLD LAPTOP
        ((AuctionItem) OldLaptop).makeBid((Buyer) Jordi,600);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //PRINT THE AUCTION ITEMS STOCK AND MANAGE THEM (24/11/2020)
        ((Administrator) Eric).printStock(auctionItems);
        manageAuctions((Administrator) Eric, new Date(2020, 11, 24));
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CALCULATE TOTAL PRICE AND TOTAL PROFIT
        calculatePrice(itemAvailable);
        calculateProfit(itemSold);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //PRINT THE AUCTION ITEMS STOCK AND MANAGE THEM (01/12/2020)
        ((Administrator) Eric).printStock(auctionItems);
        manageAuctions((Administrator) Eric, new Date(2020, 12, 01));
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        //CALCULATE TOTAL PRICE AND TOTAL PROFIT
        calculatePrice(itemAvailable);
        calculateProfit(itemSold);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");




    }
}
