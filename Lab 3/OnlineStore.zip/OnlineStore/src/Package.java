public abstract class Package {
    //ATTRIBUTES
    private int width;
    private int height;

    //CONSTRUCTOR
    public Package(int w, int h) {
        setWidth(w);
        setHeight(h);
    }

    //GETTERS
    public int getWidth() {
        return width;
    }
    public int getHeight() { return height; }

    //SETTERS
    public void setWidth(int w) {
        this.width = w;
    }
    public void setHeight(int h) {
        this.height = h;
    }

    //METHODS
    public abstract boolean isSuitable(double[] size);
    public abstract String printInfo();
}
