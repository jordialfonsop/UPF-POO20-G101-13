public class UnitItem extends Item {
    //ATTRIBUTES
    private double unitPrice;
    private int quantity;
    private int quantityRemain;

    //CONSTRUCTOR
    public UnitItem(String name, String type, double[] size, double cost, double unitPrice, int quantity) {
        super(name, type, size, cost);
        this.unitPrice = unitPrice;
        this.quantity = quantity;
        this.quantityRemain = quantity;
    }

    //GETTERS
    @Override
    public double getPrice(){
        return unitPrice * quantityRemain;
    }
    public double getUnitPrice(){
        return unitPrice;
    }
    public int getQuantity(){
        return quantity;
    }

    //METHODS
    @Override
    public double calculateProfit(){
        if(quantity-quantityRemain == 0){
            return (unitPrice-getCost()) * quantity;
        }else{
            return (unitPrice-getCost()) * (quantity-quantityRemain);
        }
    }

    public double sell(int q){
        if (quantityRemain>=q){
            this.quantityRemain = this.quantityRemain - q;
            return q*unitPrice;
        }
        return 0;
    }

}
