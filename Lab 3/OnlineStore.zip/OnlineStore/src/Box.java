public class Box extends Package {
    //ATTRIBUTES
    private int depth;

    //CONSTRUCTOR
    public Box(int w, int h, int d) {
        super(w,h);
        setDepth(d);
    }

    //GETTERS
    public int getDepth() {
        return depth;
    }

    //SETTERS
    public void setDepth(int depth) {
        this.depth = depth;
    }

    //METHODS
    @Override
    public boolean isSuitable(double[] size){
        if(size.length == 3){
            if(size[0]<=getWidth() && size[1]<=getHeight() && size[2]<=getDepth()){
                return true;
            }
        }
        return false;
    }
    @Override
    public String printInfo(){
        return ("Box with dimensions: " + getHeight() + ", " + getWidth() + ", " + getDepth());
    }
}
