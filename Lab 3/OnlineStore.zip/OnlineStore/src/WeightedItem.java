public class WeightedItem extends Item {
    //ATTRIBUTES
    private double pricePerWeight;
    private double weight;
    private double weightRemaining;

    //CONSTRUCTOR
    public WeightedItem(String name, String type, double[] size, double cost, double wprice, double w) {
        super(name, type, size, cost);
        this.pricePerWeight = wprice;
        this.weight = w;
        this.weightRemaining = weight;
    }

    //GETTERS
    @Override
    public double getPrice(){
            return pricePerWeight * weightRemaining;
    }
    public double getWeight(){
        return weight;
    }
    public double getPricePerWeight(){
        return pricePerWeight;
    }

    //METHODS
    @Override
    public double calculateProfit(){
        if(weight-weightRemaining == 0){
            return (pricePerWeight-getCost()) * weight;
        }else{
            return (pricePerWeight-getCost()) * (weight-weightRemaining);
        }
    }
    public double sell(double w){
        if (weightRemaining >= w){
            this.weightRemaining = this.weightRemaining - w;
            return w*pricePerWeight;
        }
        return 0;
    }
}
