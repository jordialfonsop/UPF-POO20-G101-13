import java.util.LinkedList;

public abstract class Item {
    //ATTRIBUTES
    private String name;
    private String type;
    private double[] size;
    private double cost;
    private Package pack;

    //CONSTRUCTOR
    public Item(String name, String type, double[] size, double cost) {
        this.name = name;
        this.type = type;
        this.size = size;
        this.cost = cost;
    }

    //GETTERS
    public String getName() {
        return name;
    }
    public String getType() {
        return type;
    }
    public double[] getSize() {
        return size;
    }
    public double getCost() {
        return cost;
    }
    public Package getPack() {
        return pack;
    }
    public abstract double getPrice();

    //SETTERS
    public void setName(String name) {
        this.name = name;
    }
    public void setType(String type) {
        this.type = type;
    }
    public void setSize(double[] size) {
        this.size = size;
    }
    public void setCost(double cost) {
        this.cost = cost;
    }

    //METHODS
    public abstract double calculateProfit();
    //PENDING
    public void assignBestPackage(LinkedList <Package> lp){
        for(int i=0; i<lp.size(); i++){
            Package p = lp.get(i);
            if(p instanceof Envelope){
                if(((Envelope) p).isSuitable(size)){
                    if(pack != null){
                        if (pack.getHeight() > p.getHeight()){
                            pack = p;
                        }
                    }else{
                        pack = p;
                    }
                    break;
                }
            }
            if(p instanceof Box){
                if(((Box) p).isSuitable(size)){
                    if(pack != null){
                        if (pack.getHeight() > p.getHeight()){
                            pack = p;
                        }
                    }else{
                        pack = p;
                    }
                    break;
                }
            }
        }
        if(pack != null) {
            System.out.println(pack.printInfo() + " assigned to item " + getName());
        }
    }



}


