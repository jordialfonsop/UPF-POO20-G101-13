public class Envelope extends Package {
    //ATTRIBUTES
    private String name;

    //CONSTRUCTOR
    public Envelope(int w, int h, String n) {
        super(w,h);
        setName(n);
    }

    //GETTERS
    public String getName() {
        return name;
    }

    //SETTERS
    public void setName(String name) {
        this.name = name;
    }

    //METHODS
    @Override
    public boolean isSuitable(double[] size){
        if(size.length==2){
            if(size[0]<=getWidth() && size[1]<= getHeight()){
                return true;
            }
        }
        return false;
    }
    @Override
    public String printInfo(){
        return ("Envelope of name: " + getName() + " with dimensions: " + getHeight() + ", " + getWidth());
    }
}